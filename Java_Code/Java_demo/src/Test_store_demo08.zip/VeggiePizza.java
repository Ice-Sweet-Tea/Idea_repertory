package Test_store_demo08;

public class VeggiePizza extends Pizza{
    public VeggiePizza() {
        this.name = "Veggie Pizza";
    }
}
