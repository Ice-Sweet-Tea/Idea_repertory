package Test_store_demo08;

public class PizzaStore {
    private SimplePizzaFactory factory;

    public PizzaStore(SimplePizzaFactory factory) {
        this.factory = factory;
    }

    public Pizza orderPizza(String type) {
        Pizza pizza = factory.createPizza(type);

        if (pizza != null) {
            pizza.prepare();
            pizza.bake();
            pizza.cut();
            pizza.box();
            System.out.println("订单： a " + pizza.getName());
        } else {
            System.out.println("没有这种类型的披萨！！！");
        }
        return pizza;
    }
}
