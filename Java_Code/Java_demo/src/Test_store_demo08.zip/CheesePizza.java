package Test_store_demo08;

public class CheesePizza extends Pizza {
    public CheesePizza() {
        this.name = "Cheese Pizza";
    }
}
