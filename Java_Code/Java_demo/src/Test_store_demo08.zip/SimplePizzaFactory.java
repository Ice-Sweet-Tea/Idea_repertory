package Test_store_demo08;

public class SimplePizzaFactory {
    public Pizza createPizza(String type) {
        Pizza pizza = null;
        if ("cheese".equalsIgnoreCase(type)) {
            pizza = new CheesePizza();
        } else if ("veggie".equalsIgnoreCase(type)) {
            pizza = new VeggiePizza();
        } else if ("clam".equalsIgnoreCase(type)) {
            pizza = new ClamPizza();
        } else if ("pepperoni".equalsIgnoreCase(type)) {
            pizza = new PepperoniPizza();
        }
        return pizza;
    }
}
