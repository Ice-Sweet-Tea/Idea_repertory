package Test_store_demo08;

public class TestDemo {
    public static void main(String[] args) {
        SimplePizzaFactory factory = new SimplePizzaFactory();
        PizzaStore store = new PizzaStore(factory);

        store.orderPizza("cheese");
        store.orderPizza("veggie");
        store.orderPizza("clam");
        store.orderPizza("pepperoni");
        store.orderPizza("unknown");
    }
}
