package Test_store_demo08;

public class ClamPizza extends Pizza{
    public ClamPizza(){
        this.name = "Clam Pizza";
    }
}
