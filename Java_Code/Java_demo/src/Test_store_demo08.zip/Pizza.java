package Test_store_demo08;

public abstract class Pizza {
    protected String name;

    public void prepare() {
        System.out.println(name + " is preparing.");
    }

    public void bake() {
        System.out.println(name + " is baking.");
    }

    public void cut() {
        System.out.println(name + " is cutting.");
    }

    public void box() {
        System.out.println(name + " is boxing.");
    }

    public String getName() {
        return name;
    }
}
