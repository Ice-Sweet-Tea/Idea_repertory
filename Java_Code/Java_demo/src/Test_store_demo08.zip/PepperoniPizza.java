package Test_store_demo08;

public class PepperoniPizza extends Pizza{
    public PepperoniPizza(){
        this.name = "Pepperoni Pizza";
    }
}
