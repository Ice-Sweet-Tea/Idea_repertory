package Test_demo12;

public class ChocolateFactorySynchronized {
    private static ChocolateFactorySynchronized instance;

    private ChocolateFactorySynchronized() {
        System.out.println("加锁懒汉式工厂启动！");
    }

    public static synchronized ChocolateFactorySynchronized getInstance() {
        if (instance == null) {
            instance = new ChocolateFactorySynchronized();
        }
        return instance;
    }

    public void makeChocolate() {
        System.out.println("生产巧克力中……🍫（加锁版本）");
    }
}
