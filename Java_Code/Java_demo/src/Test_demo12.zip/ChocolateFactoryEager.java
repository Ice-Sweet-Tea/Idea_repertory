package Test_demo12;

public class ChocolateFactoryEager {
    // 类加载时立即创建对象
    private static final ChocolateFactoryEager instance = new ChocolateFactoryEager();

    private ChocolateFactoryEager() {
        System.out.println("饿汉式工厂一启动就准备好了！");
    }

    public static ChocolateFactoryEager getInstance() {
        return instance;
    }

    public void makeChocolate() {
        System.out.println("生产巧克力中……🍫（饿汉式）");
    }
}
