package Test_demo12;

public class ChocolateFactoryLazy {
    private static ChocolateFactoryLazy instance;

    // 私有构造函数，防止外部实例化
    private ChocolateFactoryLazy() {
        System.out.println("懒汉式巧克力工厂启动！");
    }

    public static ChocolateFactoryLazy getInstance() {
        if (instance == null) { // 只有在第一次调用时才创建
            instance = new ChocolateFactoryLazy();
        }
        return instance;
    }

    public void makeChocolate() {
        System.out.println("生产巧克力中……🍫");
    }
}
