package Test_demo12;

public class TestChocolateFactory {
    public static void main(String[] args) {
        System.out.println("=== 懒汉式 ===");
        ChocolateFactoryLazy factory1 = ChocolateFactoryLazy.getInstance();
        ChocolateFactoryLazy factory2 = ChocolateFactoryLazy.getInstance();
        System.out.println(factory1 == factory2); // true

        System.out.println("\n=== 加锁懒汉式 ===");
        ChocolateFactorySynchronized f1 = ChocolateFactorySynchronized.getInstance();
        ChocolateFactorySynchronized f2 = ChocolateFactorySynchronized.getInstance();
        System.out.println(f1 == f2);

        System.out.println("\n=== 饿汉式 ===");
        ChocolateFactoryEager e1 = ChocolateFactoryEager.getInstance();
        ChocolateFactoryEager e2 = ChocolateFactoryEager.getInstance();
        System.out.println(e1 == e2);

        System.out.println("\n=== 双重检查加锁 ===");
        ChocolateFactoryDCL d1 = ChocolateFactoryDCL.getInstance();
        ChocolateFactoryDCL d2 = ChocolateFactoryDCL.getInstance();
        System.out.println(d1 == d2);
    }
}
