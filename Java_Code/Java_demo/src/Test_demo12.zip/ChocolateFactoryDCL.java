package Test_demo12;

public class ChocolateFactoryDCL {
    private static volatile ChocolateFactoryDCL instance;

    private ChocolateFactoryDCL() {
        System.out.println("双重检查加锁巧克力工厂启动！");
    }

    public static ChocolateFactoryDCL getInstance() {
        if (instance == null) {  // 第一次检查
            synchronized (ChocolateFactoryDCL.class) {
                if (instance == null) {  // 第二次检查
                    instance = new ChocolateFactoryDCL();
                }
            }
        }
        return instance;
    }

    public void makeChocolate() {
        System.out.println("生产巧克力中……🍫（DCL版本）");
    }
}
