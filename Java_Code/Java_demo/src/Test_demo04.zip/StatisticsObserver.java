package Test_demo04;

public class StatisticsObserver implements Observer{
    private double min = Double.MAX_VALUE;
    private double max = Double.MIN_VALUE;
    private double sum = 0;
    private int count = 0;

    @Override
    public void update(double price) {
        count++;
        sum += price;
        if (price < min) min = price;
        if (price > max) max = price;

        double avg = sum / count;
        System.out.println("【统计分析报告】 最低价: " + min + " 最高价: " + max + " 平均价: " + avg);
    }
}
