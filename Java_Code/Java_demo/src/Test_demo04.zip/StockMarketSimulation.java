package Test_demo04;
import java.util.Random;
public class StockMarketSimulation {
    public static void main(String[] args) {
        Stock stock = new Stock();

        // 添加观察者
        stock.attach(new CurrentPriceObserver());
        stock.attach(new StatisticsObserver());
        stock.attach(new ForecastObserver());

        Random random = new Random();
        System.out.println("===== 模拟股票价格波动（30次） =====");
        for (int i = 1; i <= 30; i++) {
            double price = 80 + random.nextDouble() * 40; // 80~120之间浮动
            System.out.println("\n【第 " + i + " 次变动】 新价格: " + price);
            stock.setPrice(price);
        }
    }
}
