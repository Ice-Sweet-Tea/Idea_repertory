package Test_demo04;

public class CurrentPriceObserver implements Observer{
    @Override
    public void update(double price) {
        System.out.println("【当前价格报告】 股票现价: " + price);
    }
}
