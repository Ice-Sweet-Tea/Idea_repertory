package Test_demo04;

public class ForecastObserver implements Observer {
    private Double lastPrice = null;

    @Override
    public void update(double price) {
        if (lastPrice == null) {
            System.out.println("【趋势预测报告】 暂无历史数据，无法预测");
        } else if (price > lastPrice) {
            System.out.println("【趋势预测报告】 股票价格呈上涨趋势");
        } else if (price < lastPrice) {
            System.out.println("【趋势预测报告】 股票价格呈下跌趋势");
        } else {
            System.out.println("【趋势预测报告】 股票价格持平");
        }
        lastPrice = price;
    }
}
