package Test_demo04;

public interface Observer {
    void update(double price);
}
