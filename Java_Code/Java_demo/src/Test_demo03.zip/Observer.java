package Test_demo03;

public interface Observer {
    void update(Product product);
}
