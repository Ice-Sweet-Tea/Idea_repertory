package Test_demo03;

public class EmailObserver implements Observer{
    private String productId;
    private String email;

    public EmailObserver(String productId, String email) {
        this.productId = productId;
        this.email = email;
    }

    @Override
    public void update(Product product) {
        if (product.getId().equals(productId)) {
            System.out.println("【邮件通知】邮箱 " + email +
                    "：您关注的商品 '" + product.getName() +
                    "' 价格已更新为: ¥" + product.getPrice());
        }
    }

    public String getProductId() { return productId; }
    public String getEmail() { return email; }
}
