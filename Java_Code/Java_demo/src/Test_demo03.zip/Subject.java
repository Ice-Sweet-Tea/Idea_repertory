package Test_demo03;
import java.util.List;
public interface Subject {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers();
    void setProduct(Product product);
}
