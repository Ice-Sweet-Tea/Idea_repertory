package Test_demo03;

public class Main {
    public static void main(String[] args) {
        // 创建商品主题
        ProductSubject subject = new ProductSubject();

        // 创建商品
        Product iPhone = new Product("P001", "iPhone 15", 5999.0);
        Product macbook = new Product("P002", "MacBook Pro", 12999.0);

        // 创建观察者
        Observer mobileUser1 = new MobileObserver("P001", "13800138000");
        Observer mobileUser2 = new MobileObserver("P002", "13900139000");
        Observer emailUser1 = new EmailObserver("P001", "user1@example.com");
        Observer emailUser2 = new EmailObserver("P002", "user2@example.com");

        // 注册观察者
        System.out.println("=== 注册观察者 ===");
        subject.registerObserver(mobileUser1);
        subject.registerObserver(mobileUser2);
        subject.registerObserver(emailUser1);
        subject.registerObserver(emailUser2);

        System.out.println("\n=== 商品价格更新 ===");
        // 更新商品价格（会触发通知）
        subject.setProduct(new Product("P001", "iPhone 15", 5499.0)); // 降价500元

        System.out.println("\n=== 另一个商品价格更新 ===");
        subject.setProduct(new Product("P002", "MacBook Pro", 11999.0)); // 降价1000元

        System.out.println("\n=== 移除一个观察者后再次更新 ===");
        subject.removeObserver(emailUser1);
        subject.setProduct(new Product("P001", "iPhone 15", 5299.0)); // 再次降价
    }
}

