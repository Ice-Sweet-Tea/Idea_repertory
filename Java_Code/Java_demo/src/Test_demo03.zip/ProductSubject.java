package Test_demo03;

import java.util.ArrayList;
import java.util.List;

public class ProductSubject implements Subject{
    private List<Observer> observers = new ArrayList<>();
    private Product product;

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
        System.out.println("添加观察者成功");
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
        System.out.println("移除观察者成功");
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(product);
        }
    }

    @Override
    public void setProduct(Product product) {
        this.product = product;
        notifyObservers(); // 商品信息更新时通知所有观察者
    }

    // 获取所有观察者（用于测试）
    public List<Observer> getObservers() {
        return observers;
    }
}
