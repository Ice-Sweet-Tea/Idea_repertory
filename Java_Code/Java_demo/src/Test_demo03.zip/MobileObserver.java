package Test_demo03;

public class MobileObserver implements Observer {
    private String productId;
    private String phoneNumber;

    public MobileObserver(String productId, String phoneNumber) {
        this.productId = productId;
        this.phoneNumber = phoneNumber;
    }

    @Override
    public void update(Product product) {
        if (product.getId().equals(productId)) {
            System.out.println("【短信通知】手机号 " + phoneNumber +
                    "：您关注的商品 '" + product.getName() +
                    "' 价格已更新为: ¥" + product.getPrice());
        }
    }

    public String getProductId() { return productId; }
    public String getPhoneNumber() { return phoneNumber; }
}
