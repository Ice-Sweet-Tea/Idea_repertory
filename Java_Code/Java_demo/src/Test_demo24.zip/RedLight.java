package Test_demo24;

public class RedLight implements LightState{
    @Override
    public void showLight() {
        System.out.println("🔴 红灯亮起：禁止车辆通行，允许行人通行。");
    }

    @Override
    public void next(TrafficLight context) {
        context.setState(new GreenLight());
        System.out.println("红灯结束 → 进入绿灯状态。");
    }
}
