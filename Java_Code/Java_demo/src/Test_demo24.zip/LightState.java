package Test_demo24;

public interface LightState {
    void showLight();
    void next(TrafficLight context);
}
