package Test_demo24;

public class TrafficLight {
    private LightState state;

    public TrafficLight() {
        this.state = new RedLight(); // 初始为红灯
    }

    public void setState(LightState state) {
        this.state = state;
    }

    public void showLight() {
        state.showLight();
    }

    public void change() {
        state.next(this);
    }
}
