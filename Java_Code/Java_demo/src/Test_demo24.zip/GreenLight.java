package Test_demo24;

public class GreenLight implements LightState{
    @Override
    public void showLight() {
        System.out.println("🟢 绿灯亮起：允许车辆通行，禁止行人通行。");
    }

    @Override
    public void next(TrafficLight context) {
        context.setState(new YellowLight());
        System.out.println("绿灯结束 → 进入黄灯状态。");
    }
}
