package Test_demo24;

public class YellowLight implements LightState{
    @Override
    public void showLight() {
        System.out.println("🟡 黄灯亮起：警示状态，请注意减速。");
    }

    @Override
    public void next(TrafficLight context) {
        context.setState(new RedLight());
        System.out.println("黄灯结束 → 进入红灯状态。");
    }
}
