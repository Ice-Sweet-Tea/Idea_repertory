package Test_demo24;

public class Client {
    public static void main(String[] args) throws InterruptedException {
        TrafficLight light = new TrafficLight();

        for (int i = 0; i < 6; i++) {
            light.showLight();
            Thread.sleep(1000); // 模拟等待1秒
            light.change();
            System.out.println("--------------------------");
        }
    }
}
