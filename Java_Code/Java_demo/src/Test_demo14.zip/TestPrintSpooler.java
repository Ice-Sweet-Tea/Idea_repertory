package Test_demo14;

public class TestPrintSpooler {
    public static void main(String[] args) {
        try {
            // 第一次创建成功
            PrintSpoolerSingleton spooler1 = PrintSpoolerSingleton.getInstance();
            spooler1.printJob("文件A.pdf");

            // 第二次尝试创建会抛异常
            PrintSpoolerSingleton spooler2 = PrintSpoolerSingleton.getInstance();
            spooler2.printJob("文件B.docx");
        } catch (RuntimeException e) {
            System.out.println("异常提示：" + e.getMessage());
        }
    }
}
