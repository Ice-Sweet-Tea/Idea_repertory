package Test_demo14;

public class PrintSpoolerSingleton {
    // 静态实例变量
    private static PrintSpoolerSingleton instance = null;

    // 私有构造函数，防止外部创建实例
    private PrintSpoolerSingleton() {
        System.out.println("打印池启动成功！");
    }

    // 获取实例的静态方法
    public static PrintSpoolerSingleton getInstance() {
        if (instance == null) {
            synchronized (PrintSpoolerSingleton.class) { // 保证线程安全
                if (instance == null) {
                    instance = new PrintSpoolerSingleton();
                }
            }
        } else {
            throw new RuntimeException("打印池已在运行，不能重复创建！");
        }
        return instance;
    }

    // 模拟打印任务
    public void printJob(String jobName) {
        System.out.println("正在打印任务：" + jobName);
    }
}
