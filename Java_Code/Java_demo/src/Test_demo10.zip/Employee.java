package Test_demo10;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

public class Employee extends IReimbursementCalculator {
    private String id;
    private String level;    // 行政级别
    private String cityType; // 城市类别
    private double trafficFee; // 交通费
    private double hotelPrice; // 实际住宿单价
    private int days;         // 出差天数
    private double totalReimbursement; // 报销金额

    // 补贴标准
    public static final Map<String, Double> subsidyMap = new HashMap<>();
    static {
        subsidyMap.put("一线城市", 90.0);
        subsidyMap.put("二线城市", 70.0);
        subsidyMap.put("三线城市", 60.0);
        subsidyMap.put("四线城市", 60.0);
    }

    // 住宿标准
    public static final Map<String, Map<String, Double>> hotelStandard = new HashMap<>();
    static {
        Map<String, Double> high = new HashMap<>();
        high.put("一线城市", 700.0);
        high.put("二线城市", 600.0);
        high.put("三线城市", 500.0);
        high.put("四线城市", 400.0);

        Map<String, Double> manager = new HashMap<>();
        manager.put("一线城市", 350.0);
        manager.put("二线城市", 300.0);
        manager.put("三线城市", 250.0);
        manager.put("四线城市", 150.0);

        Map<String, Double> staff = new HashMap<>();
        staff.put("一线城市", 270.0);
        staff.put("二线城市", 230.0);
        staff.put("三线城市", 200.0);
        staff.put("四线城市", 150.0);

        hotelStandard.put("高层", high);
        hotelStandard.put("主管", manager);
        hotelStandard.put("普通员工", staff);
    }

    // 差额比例
    private static final Map<String, Double[]> diffRule = new HashMap<>();
    static {
        diffRule.put("高层", new Double[]{0.2, 0.3});      // 超出20%自费，节省30%补贴
        diffRule.put("主管", new Double[]{0.4, 0.5});
        diffRule.put("普通员工", new Double[]{0.5, 0.7});
    }

    public Employee(String id, String level, String cityType, double trafficFee, double hotelPrice, int days) {
        this.id = id;
        this.level = level;
        this.cityType = cityType;
        this.trafficFee = trafficFee;
        this.hotelPrice = hotelPrice;
        this.days = days;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public double getTotalReimbursement() {
        return totalReimbursement;
    }

    @Override
    public void calculate() {
        double subsidy = subsidyMap.getOrDefault(cityType, 0.0) * days;

        double standard = hotelStandard.get(level).get(cityType);

        double diff = 0.0;
        if (hotelPrice > standard) {
            double exceed = hotelPrice - standard;
            diff -= exceed * diffRule.get(level)[0] * days;
        } else if (hotelPrice < standard) {
            double save = standard - hotelPrice;
            diff += save * diffRule.get(level)[1] * days;
        }

        double total = trafficFee + subsidy + hotelPrice * days + diff;
        BigDecimal bd = new BigDecimal(total).setScale(2, RoundingMode.HALF_UP);
        this.totalReimbursement = bd.doubleValue();
    }
}
