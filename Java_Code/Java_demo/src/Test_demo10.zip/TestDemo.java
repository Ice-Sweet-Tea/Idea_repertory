package Test_demo10;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TestDemo {
    public static void main(String[] args) {
        List<IReimbursementCalculator> employees = new ArrayList<>();
        File inputFile = new File("source.txt");
        File outputFile = new File("result.txt");

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                try {
                    String[] parts = line.trim().split("\\s+");
                    if (parts.length != 6) continue;

                    String id = parts[0];
                    String level = parts[1];
                    String cityType = parts[2];
                    double trafficFee = Double.parseDouble(parts[3]);
                    double hotelPrice = Double.parseDouble(parts[4]);
                    int days = Integer.parseInt(parts[5]);

                    if (!isValid(level, cityType)) continue;

                    Employee emp = new Employee(id, level, cityType, trafficFee, hotelPrice, days);
                    emp.calculate();
                    employees.add(emp);

                } catch (Exception e) {
                    // 错误数据跳过
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        employees.sort(Comparator.comparing(IReimbursementCalculator::getId));

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {
            for (IReimbursementCalculator emp : employees) {
                bw.write(emp.getId() + " " + String.format("%.2f", emp.getTotalReimbursement()));
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static boolean isValid(String level, String cityType) {
        return (Employee.hotelStandard.containsKey(level)
                && Employee.subsidyMap.containsKey(cityType));
    }
}

