package Test_demo10;

public abstract class IReimbursementCalculator {
    // 计算报销金额
    abstract void calculate();

    // 获取报销结果
    abstract double getTotalReimbursement();

    // 获取员工编号（用于排序和输出）
    abstract String getId();
}
