package Test_demo09;

public class NYPizzaStore extends PizzaStore{
    @Override
    protected Pizza createPizza() {
        return new NYStyleCheesePizza();
    }
}
