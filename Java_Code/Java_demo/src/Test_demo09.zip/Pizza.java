package Test_demo09;

public abstract class Pizza {
    protected String name;
    public void prepare() {
        System.out.println("准备 " + name);
    }
    public void bake() {
        System.out.println("烘焙 " + name);
    }
    public void cut() {
        System.out.println("切块 " + name);
    }
    public void box() {
        System.out.println("装盒 " + name);
    }
}
