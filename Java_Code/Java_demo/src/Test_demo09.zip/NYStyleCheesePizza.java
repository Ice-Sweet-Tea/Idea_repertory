package Test_demo09;

public class NYStyleCheesePizza extends Pizza{
    public NYStyleCheesePizza() {
        name = "纽约风格奶酪披萨";
    }
}
