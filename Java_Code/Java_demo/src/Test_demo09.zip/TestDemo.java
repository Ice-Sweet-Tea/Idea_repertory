package Test_demo09;

public class TestDemo {
    public static void main(String[] args) {
        PizzaStore nyStore = new NYPizzaStore();
        PizzaStore chicagoStore = new ChicagoPizzaStore();

        System.out.println("---- 订购纽约披萨 ----");
        nyStore.orderPizza();

        System.out.println("---- 订购芝加哥披萨 ----");
        chicagoStore.orderPizza();
    }
}
