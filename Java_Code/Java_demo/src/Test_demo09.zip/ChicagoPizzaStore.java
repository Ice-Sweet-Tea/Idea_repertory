package Test_demo09;

public class ChicagoPizzaStore extends PizzaStore{
    @Override
    protected Pizza createPizza() {
        return new ChicagoStyleCheesePizza();
    }
}
