package Test_demo23;

public class RunningState extends LiftState{
    @Override
    public void open() {
        System.out.println("运行中不能开门！");
    }

    @Override
    public void close() {
        System.out.println("电梯门已经关闭。");
    }

    @Override
    public void run() {
        System.out.println("电梯正在运行...");
    }

    @Override
    public void stop() {
        System.out.println("电梯停止运行...");
        context.setLiftState(Context.STOPPING_STATE);
        context.getLiftState().stop();
    }
}
