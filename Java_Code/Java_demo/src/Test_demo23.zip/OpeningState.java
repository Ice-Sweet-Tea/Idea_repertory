package Test_demo23;

public class OpeningState extends LiftState{
    @Override
    public void open() {
        System.out.println("电梯门正在打开...");
    }

    @Override
    public void close() {
        System.out.println("电梯门关闭中...");
        context.setLiftState(Context.CLOSING_STATE);
        context.getLiftState().close();
    }

    @Override
    public void run() {
        System.out.println("门开着不能运行！");
    }

    @Override
    public void stop() {
        System.out.println("电梯已停止，门保持开启状态。");
    }
}
