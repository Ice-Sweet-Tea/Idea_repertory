package Test_demo23;

public class ClosingState extends LiftState{
    @Override
    public void open() {
        System.out.println("电梯门重新打开...");
        context.setLiftState(Context.OPENING_STATE);
        context.getLiftState().open();
    }

    @Override
    public void close() {
        System.out.println("电梯门关闭...");
    }

    @Override
    public void run() {
        System.out.println("电梯开始运行...");
        context.setLiftState(Context.RUNNING_STATE);
        context.getLiftState().run();
    }

    @Override
    public void stop() {
        System.out.println("电梯停止运行...");
        context.setLiftState(Context.STOPPING_STATE);
        context.getLiftState().stop();
    }
}
