package Test_demo19;

public class DinerMenuIterator implements MenuIterator{
    private MenuItem[] items;
    private int position = 0;
    private int numberOfItems;

    public DinerMenuIterator(MenuItem[] items, int numberOfItems) {
        this.items = items;
        this.numberOfItems = numberOfItems;
    }

    public boolean hasNext() {
        return position < numberOfItems;
    }

    public MenuItem next() {
        return items[position++];
    }
}
