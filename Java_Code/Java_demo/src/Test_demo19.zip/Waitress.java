package Test_demo19;

public class Waitress {
    PancakeHouseMenu pancakeHouseMenu;
    DinerMenu dinerMenu;

    public Waitress(PancakeHouseMenu pancakeHouseMenu, DinerMenu dinerMenu) {
        this.pancakeHouseMenu = pancakeHouseMenu;
        this.dinerMenu = dinerMenu;
    }

    public void printBreakfastMenu() {
        System.out.println("=== 早餐菜单 ===");
        MenuIterator iterator = pancakeHouseMenu.createIterator();
        printMenu(iterator);
    }

    public void printLunchMenu() {
        System.out.println("=== 午餐菜单 ===");
        MenuIterator iterator = dinerMenu.createIterator();
        printMenu(iterator);
    }

    public void printMenu() {
        System.out.println("=== 所有菜单 ===");
        printBreakfastMenu();
        printLunchMenu();
    }

    private void printMenu(MenuIterator iterator) {
        while (iterator.hasNext()) {
            MenuItem menuItem = iterator.next();
            System.out.print(menuItem.getName() + ", ");
            System.out.print(menuItem.getPrice() + " -- ");
            System.out.println(menuItem.getDescription());
        }
    }

    public boolean isItemVegetarian(MenuItem menuItem) {
        return menuItem.isVegetarian();
    }
}
