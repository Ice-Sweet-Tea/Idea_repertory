package Test_demo19;

import java.util.Iterator;

public interface MenuIterator extends Iterator<MenuItem> {
    boolean hasNext();
    MenuItem next();
}
