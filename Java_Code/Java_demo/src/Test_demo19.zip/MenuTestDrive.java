package Test_demo19;

public class MenuTestDrive {
    public static void main(String[] args) {
        PancakeHouseMenu pancakeHouseMenu = new PancakeHouseMenu();
        DinerMenu dinerMenu = new DinerMenu();
        Waitress waitress = new Waitress(pancakeHouseMenu, dinerMenu);

        System.out.println("=== 打印早餐菜单 ===");
        waitress.printBreakfastMenu();

        System.out.println("\n=== 打印午餐菜单 ===");
        waitress.printLunchMenu();

        System.out.println("\n=== 打印所有菜单 ===");
        waitress.printMenu();
    }
}
