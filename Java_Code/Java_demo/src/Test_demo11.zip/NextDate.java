package Test_demo11;

public class NextDate {
    // 判断是否闰年
    public static boolean isLeapYear(int year) {
        return (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
    }

    // 求下一天
    public static int[] nextDate(int year, int month, int day) {
        int[] monthDays = {
                31,
                isLeapYear(year) ? 29 : 28,
                31, 30, 31, 30,
                31, 31, 30, 31, 30, 31
        };

        // 输入合法性校验
        if (month < 1 || month > 12) {
            throw new IllegalArgumentException("月份不合法: " + month);
        }
        if (day < 1 || day > monthDays[month - 1]) {
            throw new IllegalArgumentException("日期不合法: " + day);
        }

        // 普通情况
        if (day < monthDays[month - 1]) {
            return new int[]{year, month, day + 1};
        } else {
            if (month == 12) {
                return new int[]{year + 1, 1, 1}; // 跨年
            } else {
                return new int[]{year, month + 1, 1}; // 跨月
            }
        }
    }
}
