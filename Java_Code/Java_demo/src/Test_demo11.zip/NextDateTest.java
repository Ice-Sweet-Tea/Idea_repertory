package Test_demo11;

public class NextDateTest {
    public static void main(String[] args) {
        int[][] tests = {
                {2023, 3, 15},   // 普通日
                {2023, 4, 30},   // 月末
                {2023, 12, 31},  // 跨年
                {2023, 2, 28},   // 平年2月
                {2024, 2, 28},   // 闰年2月28
                {2024, 2, 29},   // 闰年2月29
        };

        for (int[] t : tests) {
            int[] result = NextDate.nextDate(t[0], t[1], t[2]);
            System.out.printf("输入 %d-%02d-%02d → 输出 %d-%02d-%02d%n",
                    t[0], t[1], t[2], result[0], result[1], result[2]);
        }

        // 非法输入测试
        try {
            NextDate.nextDate(2023, 13, 10);
        } catch (Exception e) {
            System.out.println("非法月份测试通过: " + e.getMessage());
        }

        try {
            NextDate.nextDate(2023, 2, 30);
        } catch (Exception e) {
            System.out.println("非法日期测试通过: " + e.getMessage());
        }
    }
}
