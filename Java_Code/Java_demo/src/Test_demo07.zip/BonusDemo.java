package Test_demo07;

public class BonusDemo {
    public static void main(String[] args) {
        BonusContext context = new BonusContext();
        context.setSales(100000);
        context.setTotalReceipts(200000);
        context.setTeamSales(500000);
        context.setLastMonthSales(90000);

        // 业务经理：个人+团队奖金
        BonusCalculator managerBonus = new TeamBonusDecorator(
                new PersonalBonusDecorator(
                        new BaseBonus()));
        // 普通员工：个人+累计奖金
        BonusCalculator staffBonus = new AccumulativeBonusDecorator(
                new PersonalBonusDecorator(
                        new BaseBonus()));

        System.out.println("Manager Bonus: " + managerBonus.calculate(context));
        System.out.println("Staff Bonus: " + staffBonus.calculate(context));
    }
}
