package Test_demo07;

public class BonusDecorator implements BonusCalculator{
    protected BonusCalculator decorated;
    public BonusDecorator(BonusCalculator decorated) {
        this.decorated = decorated;
    }
    @Override
    public double calculate(BonusContext context) {
        return decorated.calculate(context);
    }
}
