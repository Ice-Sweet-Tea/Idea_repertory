package Test_demo07;

public interface BonusCalculator {
    double calculate(BonusContext context);
}
