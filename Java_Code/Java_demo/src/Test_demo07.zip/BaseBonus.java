package Test_demo07;

public class BaseBonus implements BonusCalculator{
    @Override
    public double calculate(BonusContext context) {
        return 0; // 基础奖金为0，可被装饰器递增
    }
}
