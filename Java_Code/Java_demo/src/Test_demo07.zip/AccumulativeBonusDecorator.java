package Test_demo07;

public class AccumulativeBonusDecorator extends BonusDecorator {
    public AccumulativeBonusDecorator(BonusCalculator decorated) {
        super(decorated);
    }
    @Override
    public double calculate(BonusContext context) {
        double base = super.calculate(context);
        return base + context.getTotalReceipts() * 0.001;
    }
}
