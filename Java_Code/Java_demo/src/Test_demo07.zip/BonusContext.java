package Test_demo07;

public class BonusContext {
    private double sales;
    private double totalReceipts;
    private double teamSales;
    private double lastMonthSales;

    public void setSales(int sales) {
        this.sales = sales;
    }

    public void setTotalReceipts(int totalReceipts) {
        this.totalReceipts = totalReceipts;
    }

    public void setTeamSales(int teamSales) {
        this.teamSales = teamSales;
    }

    public void setLastMonthSales(int lastMonthSales) {
        this.lastMonthSales = lastMonthSales;
    }

    public double getSales() {
        return sales;
    }

    public double getLastMonthSales() {
        return lastMonthSales;
    }

    public double getTotalReceipts() {
        return totalReceipts;
    }

    public double getTeamSales() {
        return teamSales;
    }
}
