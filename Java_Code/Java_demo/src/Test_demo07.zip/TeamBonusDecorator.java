package Test_demo07;

public class TeamBonusDecorator extends BonusDecorator {
    public TeamBonusDecorator(BonusCalculator decorated) {
        super(decorated);
    }
    @Override
    public double calculate(BonusContext context) {
        double base = super.calculate(context);
        return base + context.getTeamSales() * 0.01;
    }
}
