package Test_demo07;

public class PersonalBonusDecorator extends BonusDecorator {
    public PersonalBonusDecorator(BonusCalculator decorated) {
        super(decorated);
    }
    @Override
    public double calculate(BonusContext context) {
        double base = super.calculate(context);
        return base + context.getSales() * 0.03;
    }
}
