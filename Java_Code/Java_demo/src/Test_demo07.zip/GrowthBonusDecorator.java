package Test_demo07;

public class GrowthBonusDecorator extends BonusDecorator {
    public GrowthBonusDecorator(BonusCalculator decorated) {
        super(decorated);
    }
    @Override
    public double calculate(BonusContext context) {
        double base = super.calculate(context);
        double growthRate = (context.getSales() - context.getLastMonthSales()) / context.getLastMonthSales();
        if (growthRate > 0.1) {
            return base + context.getSales() * 0.05;
        }
        return base;
    }
}
