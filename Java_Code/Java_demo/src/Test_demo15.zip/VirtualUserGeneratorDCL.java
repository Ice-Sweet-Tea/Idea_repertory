package Test_demo15;

public class VirtualUserGeneratorDCL {
    private static volatile VirtualUserGeneratorDCL instance;

    private VirtualUserGeneratorDCL() {
    }

    public static VirtualUserGeneratorDCL getInstance() {
        if (instance == null) {
            synchronized (VirtualUserGeneratorDCL.class) {
                if (instance == null) {
                    instance = new VirtualUserGeneratorDCL();
                }
            }
        }
        return instance;
    }

    public void generateUser() {
        System.out.println("虚拟用户已生成（DCL）");
    }
}
