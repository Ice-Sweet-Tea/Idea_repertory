package Test_demo15;

public class VirtualUserGeneratorLoDH {
    private VirtualUserGeneratorLoDH() {
    }

    private static class Holder {
        private static final VirtualUserGeneratorLoDH INSTANCE = new VirtualUserGeneratorLoDH();
    }

    public static VirtualUserGeneratorLoDH getInstance() {
        return Holder.INSTANCE;
    }

    public void generateUser() {
        System.out.println("虚拟用户已生成（LoDH）");
    }
}
