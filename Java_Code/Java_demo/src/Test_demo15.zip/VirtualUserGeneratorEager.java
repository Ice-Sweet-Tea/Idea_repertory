package Test_demo15;

public class VirtualUserGeneratorEager {
    private static final VirtualUserGeneratorEager instance = new VirtualUserGeneratorEager();

    private VirtualUserGeneratorEager() {
        // 私有构造，防止外部实例化
    }

    public static VirtualUserGeneratorEager getInstance() {
        return instance;
    }

    public void generateUser() {
        System.out.println("虚拟用户已生成（饿汉式）");
    }
}
