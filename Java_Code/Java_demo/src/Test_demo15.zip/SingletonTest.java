package Test_demo15;

public class SingletonTest {
    public static void main(String[] args) {
        System.out.println("=== 饿汉式单例 ===");
        VirtualUserGeneratorEager eager1 = VirtualUserGeneratorEager.getInstance();
        VirtualUserGeneratorEager eager2 = VirtualUserGeneratorEager.getInstance();
        eager1.generateUser();
        System.out.println("eager1 == eager2 ? " + (eager1 == eager2));

        System.out.println("\n=== 双重检测锁 DCL ===");
        VirtualUserGeneratorDCL dcl1 = VirtualUserGeneratorDCL.getInstance();
        VirtualUserGeneratorDCL dcl2 = VirtualUserGeneratorDCL.getInstance();
        dcl1.generateUser();
        System.out.println("dcl1 == dcl2 ? " + (dcl1 == dcl2));

        System.out.println("\n=== 静态内部类 LoDH ===");
        VirtualUserGeneratorLoDH loDH1 = VirtualUserGeneratorLoDH.getInstance();
        VirtualUserGeneratorLoDH loDH2 = VirtualUserGeneratorLoDH.getInstance();
        loDH1.generateUser();
        System.out.println("loDH1 == loDH2 ? " + (loDH1 == loDH2));

        System.out.println("\n=== 多线程测试 DCL ===");
        Runnable task = () -> {
            VirtualUserGeneratorDCL instance = VirtualUserGeneratorDCL.getInstance();
            System.out.println(Thread.currentThread().getName() + " 获取实例: " + instance);
        };

        Thread t1 = new Thread(task, "线程A");
        Thread t2 = new Thread(task, "线程B");
        t1.start();
        t2.start();
    }
}
