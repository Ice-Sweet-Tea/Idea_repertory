package Test_demo18;

class TVOpenCommand implements AbstractCommand{
    private Television tv;

    public TVOpenCommand(Television tv) {
        this.tv = tv;
    }

    @Override
    public void execute() {
        tv.open();
    }
}
