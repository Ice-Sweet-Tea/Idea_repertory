package Test_demo18;

public class TVChangeCommand implements AbstractCommand{
    private Television tv;

    public TVChangeCommand(Television tv) {
        this.tv = tv;
    }

    @Override
    public void execute() {
        tv.changeChannel();
    }
}
