package Test_demo18;

public class CommandPatternExample {
    public static void main(String[] args) {
        Television tv = new Television();
        AbstractCommand openCommand = new TVOpenCommand(tv);
        AbstractCommand closeCommand = new TVCloseCommand(tv);
        AbstractCommand changeCommand = new TVChangeCommand(tv);

        Controller controller = new Controller(openCommand, closeCommand, changeCommand);
        controller.open();
        controller.change();
        controller.close();
    }
}
