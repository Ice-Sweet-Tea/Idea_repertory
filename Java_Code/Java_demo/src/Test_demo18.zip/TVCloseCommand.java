package Test_demo18;

public class TVCloseCommand implements AbstractCommand{
    private Television tv;

    public TVCloseCommand(Television tv) {
        this.tv = tv;
    }

    @Override
    public void execute() {
        tv.close();
    }
}
