package Test_demo18;

class Television {
    public void open() {
        System.out.println("电视机打开");
    }

    public void close() {
        System.out.println("电视机关闭");
    }

    public void changeChannel() {
        System.out.println("切换频道");
    }
}
