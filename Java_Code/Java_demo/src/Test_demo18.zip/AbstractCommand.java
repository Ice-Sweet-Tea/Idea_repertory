package Test_demo18;

interface AbstractCommand {
    void execute();
}
