package Test_demo21;

public class PatternTest {
    public static void main(String[] args) {
        // 测试迭代器模式
        MyCollection<String> collection = new MyCollection<>(5);
        collection.add("A");
        collection.add("B");
        collection.add("C");

        System.out.println("迭代器模式测试：");
        for (String item : collection) {
            System.out.println(item);
        }

        // 测试组合模式
        Directory root = new Directory("根目录");
        File file1 = new File("文档.txt");
        Directory subDir = new Directory("图片");
        File file2 = new File("照片.jpg");

        root.add(file1);
        root.add(subDir);
        subDir.add(file2);

        System.out.println("\n组合模式测试：");
        root.display("");
    }
}
