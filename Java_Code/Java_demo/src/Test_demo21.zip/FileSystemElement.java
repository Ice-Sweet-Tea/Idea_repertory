package Test_demo21;

import java.util.ArrayList;
import java.util.List;

abstract class FileSystemElement {
    protected String name;

    public FileSystemElement(String name) {
        this.name = name;
    }

    public abstract void display(String indent);
}
// 文件（叶子）
class File extends FileSystemElement {
    public File(String name) {
        super(name);
    }

    @Override
    public void display(String indent) {
        System.out.println(indent + "📄 " + name);
    }
}

// 目录（复合节点）
class Directory extends FileSystemElement {
    private List<FileSystemElement> children = new ArrayList<>();

    public Directory(String name) {
        super(name);
    }

    public void add(FileSystemElement element) {
        children.add(element);
    }

    @Override
    public void display(String indent) {
        System.out.println(indent + "📁 " + name);
        for (FileSystemElement child : children) {
            child.display(indent + "  ");
        }
    }
}