package Test_demo17;

public interface Command {
        void execute();
        void undo();
}
