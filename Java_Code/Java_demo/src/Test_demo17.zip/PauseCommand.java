package Test_demo17;

public class PauseCommand implements Command{
    private Player player;
    public PauseCommand(Player player) { this.player = player; }
    public void execute() { player.pause(); }
    public void undo() { player.play(); }
}
