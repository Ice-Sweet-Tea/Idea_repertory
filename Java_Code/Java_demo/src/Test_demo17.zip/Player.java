package Test_demo17;

public class Player {
    public void play() {
        System.out.println("播放器开始播放音乐...");
    }

    public void pause() {
        System.out.println("播放器暂停播放。");
    }

    public void stop() {
        System.out.println("播放器停止播放。");
    }

    public void forward() {
        System.out.println("快进进度条中...");
    }
}
