package Test_demo17;

public class PlayCommand implements Command{
    private Player player;
    public PlayCommand(Player player) { this.player = player; }
    public void execute() { player.play(); }
    public void undo() { player.stop(); }
}

