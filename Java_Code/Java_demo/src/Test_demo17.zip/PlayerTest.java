package Test_demo17;

public class PlayerTest {
    public static void main(String[] args) {
        Player player = new Player();
        Controller controller = new Controller();

        // 创建命令对象
        Command play = new PlayCommand(player);
        Command pause = new PauseCommand(player);
        Command stop = new StopCommand(player);
        Command forward = new ForwardCommand(player);

        // 将命令交给控制器
        controller.setCommands(play, pause, stop, forward);

        // 模拟操作
        controller.pressPlay();
        controller.pressForward();
        controller.pressPause();
        controller.pressUndo();
        controller.pressStop();
    }
}
