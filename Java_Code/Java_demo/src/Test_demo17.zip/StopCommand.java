package Test_demo17;

public class StopCommand implements Command{
    private Player player;
    public StopCommand(Player player) { this.player = player; }
    public void execute() { player.stop(); }
    public void undo() { player.play(); }
}
