package Test_demo17;

public class Controller {
    private Command playCommand;
    private Command pauseCommand;
    private Command stopCommand;
    private Command forwardCommand;
    private Command lastCommand;

    public void setCommands(Command play, Command pause, Command stop, Command forward) {
        this.playCommand = play;
        this.pauseCommand = pause;
        this.stopCommand = stop;
        this.forwardCommand = forward;
    }

    public void pressPlay() { playCommand.execute(); lastCommand = playCommand; }
    public void pressPause() { pauseCommand.execute(); lastCommand = pauseCommand; }
    public void pressStop() { stopCommand.execute(); lastCommand = stopCommand; }
    public void pressForward() { forwardCommand.execute(); lastCommand = forwardCommand; }

    public void pressUndo() {
        if (lastCommand != null) {
            System.out.println("撤销上一个操作：");
            lastCommand.undo();
        }
    }
}
