package Test_demo17;

public class ForwardCommand implements Command{
    private Player player;
    public ForwardCommand(Player player) { this.player = player; }
    public void execute() { player.forward(); }
    public void undo() { System.out.println("撤销快进，返回上一个播放位置。"); }
}
