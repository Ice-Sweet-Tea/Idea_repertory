package Test_demo13;

import java.io.IOException;

public class TestLogger {
    public static void main(String[] args) throws IOException {
        LogManager log1 = LogManager.getInstance();
        LogManager log2 = LogManager.getInstance();

        System.out.println("两个日志管理器是否同一个对象？ " + (log1 == log2));

        log1.log("系统启动...");
        log2.log("用户登录成功！");
        log1.log("数据保存完成。");
    }
}
