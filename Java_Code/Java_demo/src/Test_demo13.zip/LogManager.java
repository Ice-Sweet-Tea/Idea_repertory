package Test_demo13;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

public class LogManager {
    // 1. 定义唯一实例
    private static LogManager instance;

    // 2. 私有构造函数（禁止外部创建）
    private LogManager() {
        System.out.println("日志管理器启动成功");
    }

    // 3. 获取唯一实例（线程安全双重检查写法）
    public static LogManager getInstance() {
        if (instance == null) {
            synchronized (LogManager.class) {
                if (instance == null) {
                    instance = new LogManager();
                }
            }
        }
        return instance;
    }

    // 4. 写日志功能
    public void log(String message) throws IOException {
        try (FileWriter fw = new FileWriter("system.log", true)) {
            fw.write(LocalDateTime.now() + " - " + message + "\n");
            fw.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
