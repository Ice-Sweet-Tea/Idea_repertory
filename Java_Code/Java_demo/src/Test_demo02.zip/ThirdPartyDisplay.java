package Test_demo02;

import Test_demo02.DisplayElement;
import Test_demo02.Observer;
import Test_demo02.Subject;

public class ThirdPartyDisplay implements Observer, DisplayElement {
    private Subject weatherData;

    public ThirdPartyDisplay(Subject weatherData) {
        this.weatherData = weatherData;
        weatherData.registerObserver(this);
    }

    @Override
    public void update() {
        // 自定义更新逻辑
        display();
    }

    @Override
    public void display() {
        System.out.println("第三方显示：基于天气数据的自定义显示");
    }
}
