package Test_demo02;

public class HeatIndexDisplay implements Observer, DisplayElement {
    private float temperature;
    private float humidity;
    private float heatIndex;
    private Subject weatherData;

    public HeatIndexDisplay(Subject weatherData) {
        this.weatherData = weatherData;
        weatherData.registerObserver(this);
    }

    @Override
    public void update() {
        if (weatherData instanceof WeatherData) {
            WeatherData wd = (WeatherData) weatherData;
            this.temperature = wd.getTemperature();
            this.humidity = wd.getHumidity();
            this.heatIndex = computeHeatIndex(temperature, humidity);
            display();
        }
    }

    @Override
    public void display() {
        System.out.println("酷热指数: " + String.format("%.2f", heatIndex) + "°F");
        System.out.println("温度感受: " + getHeatIndexDescription(heatIndex));
    }

    private float computeHeatIndex(float t, float rh) {
        // 酷热指数计算公式
        return (float)(16.923 + 1.85212 * 0.1 * t + 5.37941 * rh - 1.00254 * 0.1 * t * rh
                + 9.41695 * 0.001 * t * t + 7.28898 * 0.001 * rh * rh
                + 3.45372 * 0.0001 * t * t * rh - 8.14971 * 0.0001 * t * rh * rh
                + 1.02102 * 0.00001 * t * t * rh * rh - 3.8646 * 0.00001 * t * t * t
                + 2.91583 * 0.00001 * rh * rh * rh + 1.42721 * 0.000001 * t * t * t * rh
                + 1.97483 * 0.0000001 * t * rh * rh * rh - 2.18429 * 0.00000001 * t * t * t * rh * rh
                + 8.43296 * 0.0000000001 * t * t * rh * rh * rh - 4.81975 * 0.00000000001 * t * t * t * rh * rh * rh);
    }

    private String getHeatIndexDescription(float heatIndex) {
        if (heatIndex < 80) return "舒适";
        else if (heatIndex < 90) return "注意防暑";
        else if (heatIndex < 105) return "炎热，避免户外活动";
        else if (heatIndex < 130) return "极度炎热，危险";
        else return "极其危险，避免外出";
    }
}
