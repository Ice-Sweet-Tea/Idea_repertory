package Test_demo02;

public class ForecastDisplay implements Observer,DisplayElement{
    private float currentPressure = 29.92f;
    private float lastPressure;
    private Subject weatherData;

    public ForecastDisplay(Subject weatherData) {
        this.weatherData = weatherData;
        weatherData.registerObserver(this);
    }

    @Override
    public void update() {
        if (weatherData instanceof WeatherData) {
            WeatherData wd = (WeatherData) weatherData;
            lastPressure = currentPressure;
            currentPressure = wd.getPressure();
            display();
        }
    }

    @Override
    public void display() {
        System.out.print("预报: ");
        if (currentPressure > lastPressure) {
            System.out.println("一路上天气转好!");
        } else if (currentPressure == lastPressure) {
            System.out.println("更多同样的内容");
        } else if (currentPressure < lastPressure) {
            System.out.println("注意降温和多雨的天气");
        }
    }
}
