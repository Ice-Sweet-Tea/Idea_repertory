package Test_demo02;

public interface Observer {
    void update();
}
