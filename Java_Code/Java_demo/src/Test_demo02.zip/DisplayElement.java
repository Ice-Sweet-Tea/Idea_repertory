package Test_demo02;

public interface DisplayElement {
    void display();
}
