package Test_demo22;

public class GumballMachine {
    private final State soldOutState;
    private final State noQuarterState;
    private final State hasQuarterState;
    private final State soldState;
    private final State winnerState;

    private State state;
    private int count = 0;

    public GumballMachine(int count) {
        this.count = count;

        soldOutState = new SoldOutState(this);
        noQuarterState = new NoQuarterState(this);
        hasQuarterState = new HasQuarterState(this);
        soldState = new SoldState(this);
        winnerState = new WinnerState(this);

        if (count > 0) {
            state = noQuarterState;
        } else {
            state = soldOutState;
        }
    }

    public void insertQuarter() { state.insertQuarter(); }
    public void ejectQuarter() { state.ejectQuarter(); }
    public void turnCrank() {
        state.turnCrank();
        state.dispense();
    }

    void releaseBall() {
        if (count > 0) {
            System.out.println("发放一颗糖果~");
            count--;
        }
    }

    // Getter & Setter
    public void setState(State state) { this.state = state; }
    public int getCount() { return count; }

    public State getSoldOutState() { return soldOutState; }
    public State getNoQuarterState() { return noQuarterState; }
    public State getHasQuarterState() { return hasQuarterState; }
    public State getSoldState() { return soldState; }
    public State getWinnerState() { return winnerState; }

    @Override
    public String toString() {
        return "\n糖果机状态：" + state.getClass().getSimpleName() + " | 剩余糖果数：" + count;
    }
}
