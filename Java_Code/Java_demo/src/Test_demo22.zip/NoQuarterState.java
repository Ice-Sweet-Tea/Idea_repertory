package Test_demo22;

public class NoQuarterState implements State{
    private final GumballMachine gumballMachine;

    public NoQuarterState(GumballMachine machine) {
        this.gumballMachine = machine;
    }

    @Override
    public void insertQuarter() {
        System.out.println("你投入了25分钱");
        gumballMachine.setState(gumballMachine.getHasQuarterState());
    }

    @Override
    public void ejectQuarter() {
        System.out.println("你还没有投币，不能退钱");
    }

    @Override
    public void turnCrank() {
        System.out.println("请先投币再转动曲柄");
    }

    @Override
    public void dispense() {
        System.out.println("请先付款");
    }
}
