package Test_demo22;

public class SoldOutState implements State{
    private final GumballMachine gumballMachine;

    public SoldOutState(GumballMachine machine) {
        this.gumballMachine = machine;
    }

    @Override
    public void insertQuarter() {
        System.out.println("糖果已售罄，不能投币");
    }

    @Override
    public void ejectQuarter() {
        System.out.println("未投币，无法退钱");
    }

    @Override
    public void turnCrank() {
        System.out.println("糖果售罄，转也没用");
    }

    @Override
    public void dispense() {
        System.out.println("没有糖果可以发放");
    }
}
