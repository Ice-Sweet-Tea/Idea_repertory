package Test_demo22;

public class WinnerState implements State{
    private final GumballMachine gumballMachine;

    public WinnerState(GumballMachine machine) {
        this.gumballMachine = machine;
    }

    @Override
    public void insertQuarter() {
        System.out.println("请稍等，正在发放糖果...");
    }

    @Override
    public void ejectQuarter() {
        System.out.println("抱歉，不能退钱");
    }

    @Override
    public void turnCrank() {
        System.out.println("不能重复转动曲柄");
    }

    @Override
    public void dispense() {
        System.out.println("恭喜你是幸运用户！获得两颗糖果！");
        gumballMachine.releaseBall();
        if (gumballMachine.getCount() == 0) {
            gumballMachine.setState(gumballMachine.getSoldOutState());
        } else {
            gumballMachine.releaseBall();
            if (gumballMachine.getCount() > 0) {
                gumballMachine.setState(gumballMachine.getNoQuarterState());
            } else {
                System.out.println("糖果售罄");
                gumballMachine.setState(gumballMachine.getSoldOutState());
            }
        }
    }
}
