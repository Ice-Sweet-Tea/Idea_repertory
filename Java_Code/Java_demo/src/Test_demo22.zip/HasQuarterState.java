package Test_demo22;

import java.util.Random;

public class HasQuarterState implements State{
    private final GumballMachine gumballMachine;
    private final Random randomWinner = new Random();

    public HasQuarterState(GumballMachine machine) {
        this.gumballMachine = machine;
    }

    @Override
    public void insertQuarter() {
        System.out.println("已经投过币了，不能再投");
    }

    @Override
    public void ejectQuarter() {
        System.out.println("退回25分钱");
        gumballMachine.setState(gumballMachine.getNoQuarterState());
    }

    @Override
    public void turnCrank() {
        System.out.println("你转动了曲柄...");
        int winner = randomWinner.nextInt(10); // 10% 概率
        if (winner == 0 && gumballMachine.getCount() > 1) {
            gumballMachine.setState(gumballMachine.getWinnerState());
        } else {
            gumballMachine.setState(gumballMachine.getSoldState());
        }
    }

    @Override
    public void dispense() {
        System.out.println("还没转动曲柄，不能发糖果");
    }
}
