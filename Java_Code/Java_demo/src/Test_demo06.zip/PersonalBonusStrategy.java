package Test_demo06;

public class PersonalBonusStrategy implements BonusStrategy{
    @Override
    public double calculate(BonusContext context) {
        return context.getSales() * 0.03;
    }
}
