package Test_demo06;

public class TeamBonusStrategy implements BonusStrategy{
    @Override
    public double calculate(BonusContext context) {
        return context.getTeamSales() * 0.01;
    }
}
