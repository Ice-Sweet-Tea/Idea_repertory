package Test_demo06;

public interface BonusStrategy {
    double calculate(BonusContext context);
}
