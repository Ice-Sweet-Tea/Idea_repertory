package Test_demo06;

public class AccumulativeBonusStrategy implements BonusStrategy{
    @Override
    public double calculate(BonusContext context) {
        return context.getTotalReceipts() * 0.001;
    }
}
