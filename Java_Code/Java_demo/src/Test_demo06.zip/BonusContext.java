package Test_demo06;

public class BonusContext {
    private double sales;         // 销售额
    private double totalReceipts; // 总回款额
    private double teamSales;     // 团队销售额
    private double lastMonthSales;// 上月销售额

    public void setTotalReceipts(int totalReceipts) {
        this.totalReceipts = totalReceipts;
    }

    public double getSales() {
        return sales;
    }

    public double getTotalReceipts() {
        return totalReceipts;
    }

    public double getTeamSales() {
        return teamSales;
    }

    public double getLastMonthSales() {
        return lastMonthSales;
    }

    public void setSales(int sales) {
        this.sales = sales;
    }

    public void setTeamSales(int teamSales) {
        this.teamSales = teamSales;
    }

    public void setLastMonthSales(int lastMonthSales) {
        this.lastMonthSales = lastMonthSales;
    }
}
