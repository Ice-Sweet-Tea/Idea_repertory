package Test_demo06;

public class BonusDemo {
    public static void main(String[] args) {
        BonusContext context = new BonusContext();
        context.setSales(100000);
        context.setTotalReceipts(200000);
        context.setTeamSales(500000);
        context.setLastMonthSales(90000);

        CompositeBonusStrategy managerBonus = new CompositeBonusStrategy();
        managerBonus.addStrategy(new PersonalBonusStrategy());
        managerBonus.addStrategy(new TeamBonusStrategy());

        CompositeBonusStrategy staffBonus = new CompositeBonusStrategy();
        staffBonus.addStrategy(new PersonalBonusStrategy());
        staffBonus.addStrategy(new AccumulativeBonusStrategy());

        System.out.println("Manager Bonus: " + managerBonus.calculate(context));
        System.out.println("Staff Bonus: " + staffBonus.calculate(context));
    }
    }

