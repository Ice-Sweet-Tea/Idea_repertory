package Test_demo06;
import java.util.ArrayList;
import java.util.List;

public class CompositeBonusStrategy implements BonusStrategy{
    private List<BonusStrategy> strategies = new ArrayList<>();

    public void addStrategy(BonusStrategy strategy) {
        strategies.add(strategy);
    }
    public void removeStrategy(BonusStrategy strategy) {
        strategies.remove(strategy);
    }
    @Override
    public double calculate(BonusContext context) {
        double total = 0;
        for (BonusStrategy strategy : strategies) {
            total += strategy.calculate(context);
        }
        return total;
    }
}
