package Test_demo06;

public class GrowthBonusStrategy implements BonusStrategy{
    @Override
    public double calculate(BonusContext context) {
        double growthRate = (context.getSales() - context.getLastMonthSales()) / context.getLastMonthSales();
        if (growthRate > 0.1) { // 增长超过10%
            return context.getSales() * 0.05;
        }
        return 0;
    }
}
