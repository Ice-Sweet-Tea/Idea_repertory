package Test_demo16;

public class WaSher {
    public void on(){
        System.out.println("小爱打开洗衣机!!!");
    }

    public void off(){
        System.out.println("小爱关闭洗衣机!!!");
    }
}
