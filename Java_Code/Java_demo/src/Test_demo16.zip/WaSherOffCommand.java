package Test_demo16;

public class WaSherOffCommand implements Command{
    private WaSher washer;

    public WaSherOffCommand(WaSher washer) {
        this.washer = washer;
    }

    @Override
    public void execute() {
        washer.off();
    }

    @Override
    public void undo() {
        washer.on();
    }
}
