package Test_demo16;

public class TV {
    public void on(){
        System.out.println("小爱打开电视!!!");
    }

    public void off(){
        System.out.println("小爱关掉电视!!!");
    }
}
