package Test_demo16;

public interface Command {
    void execute();
    void undo(); // 撤销功能
}
