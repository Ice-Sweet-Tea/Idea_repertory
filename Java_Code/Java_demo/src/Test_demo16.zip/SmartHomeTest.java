package Test_demo16;

public class SmartHomeTest {
    public static void main(String[] args) {
        RemoteControl remote = new RemoteControl();

        // 创建对象
        Light light = new Light();
        Fan fan = new Fan();
        IceBox icebox = new IceBox();
        WaSher washer = new WaSher();
        TV tv = new TV();

        // 创建命令
        LightOnCommand lightOn = new LightOnCommand(light);
        LightOffCommand lightOff = new LightOffCommand(light);

        FanOnCommand fanOn = new FanOnCommand(fan);
        FanOffCommand fanOff = new FanOffCommand(fan);

        IceBoxOnCommand iceboxOn = new IceBoxOnCommand(icebox);
        IceBoxOffCommand iceboxOff = new IceBoxOffCommand(icebox);

        WaSherOnCommand washerOn = new WaSherOnCommand(washer);
        WaSherOffCommand washerOff = new WaSherOffCommand(washer);

        TvOnCommand tvOn = new TvOnCommand(tv);
        TvOffCommand tvOff = new TvOffCommand(tv);

        // 设置遥控器按钮
        remote.setCommand(0, lightOn, lightOff); // 第1个按钮控制电灯
        remote.setCommand(1, fanOn, fanOff);     // 第2个按钮控制风扇
        remote.setCommand(2, iceboxOn, iceboxOff);     // 第3个按钮控制冰箱按钮
        remote.setCommand(3,washerOn,washerOff);       // 第4个按钮控制洗衣机按钮
        remote.setCommand(4,tvOn,tvOff);// 第5个按钮控制电视按钮
        // 使用遥控器
        remote.pressOn(0);   // 电灯开
        remote.pressOff(0);  // 电灯关
        remote.pressUndo();  // 撤销电灯操作

        System.out.println("--------");

        remote.pressOn(1);   // 风扇开
        remote.pressUndo();  // 撤销风扇操作

        System.out.println("--------");

        remote.pressOn(2); //冰箱开
        remote.pressOff(2); //冰箱关
        remote.pressUndo();// 撤销冰箱操作

        System.out.println("--------");

        remote.pressOn(3); //洗衣机开
        remote.pressOff(3);//洗衣机关
        remote.pressUndo();// 撤销冰箱操作

        System.out.println("--------");

        remote.pressOn(4);
        remote.pressOff(4);
        remote.pressUndo();// 撤销冰箱操作

    }
}
