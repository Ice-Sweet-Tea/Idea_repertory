package Test_demo16;

public class IceBox{
    public void on() { System.out.println("冰箱打开"); }
    public void off() { System.out.println("冰箱关闭"); }
}
