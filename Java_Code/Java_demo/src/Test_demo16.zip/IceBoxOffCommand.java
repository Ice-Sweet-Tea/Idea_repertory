package Test_demo16;

public class IceBoxOffCommand implements Command {
    private IceBox icebox;

    public IceBoxOffCommand(IceBox icebox) {
        this.icebox = icebox;
    }

    public void execute() {
        icebox.off();
    }

    public void undo() {
        icebox.on();
    }
}
