package Test_demo16;

public class Fan {
    public void on() { System.out.println("风扇打开"); }
    public void off() { System.out.println("风扇关闭"); }
}
