package Test_demo16;
// 空命令类（用于初始化按钮）
public class NoCommand implements Command{
    public void execute() {}
    public void undo() {}
}
