package Test_demo16;

public class WaSherOnCommand implements Command{
    private WaSher washer;

    public WaSherOnCommand(WaSher washer) {
        this.washer = washer;
    }

    @Override
    public void execute() {
        washer.on();
    }

    @Override
    public void undo() {
        washer.off();
    }
}
