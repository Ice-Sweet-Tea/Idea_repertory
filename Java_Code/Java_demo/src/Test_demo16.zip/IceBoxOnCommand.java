package Test_demo16;

public class IceBoxOnCommand implements Command{
    private IceBox icebox;

    public IceBoxOnCommand(IceBox icebox) {
        this.icebox = icebox;
    }

    public void execute() { icebox.on(); }
    public void undo() { icebox.off(); }
}
